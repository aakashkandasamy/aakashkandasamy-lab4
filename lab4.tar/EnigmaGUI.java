import javax.swing.SwingUtilities;

public class EnigmaGUI {
    public static void main(String[] args) {
        // create and show the frame
        EnigmaFrame myFrame = new EnigmaFrame();
        myFrame.setVisible(true);
    }
}
